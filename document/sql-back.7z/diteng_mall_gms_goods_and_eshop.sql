create table gms_goods_and_eshop
(
    uid             int unsigned auto_increment comment '主键UID'
        primary key,
    corp_no         varchar(10)             not null comment '账套代码',
    goods_code      varchar(18)             not null comment '商品料号',
    status_         int(3)                  not null comment '启用状态',
    eshop_type      int                     not null comment '电商平台类型',
    eshop_name      varchar(30)             not null comment '电商平台名称',
    eshop_goods_url varchar(255) default '' not null comment '商品在电商平台的链接',
    constraint gms_goods_and_eshop_corp_no_goods_code_eshop_type_uindex
        unique (corp_no, goods_code, eshop_type)
)
    comment '商品与电商平台链接关联表';

create index idx_goodsAndEshop
    on gms_goods_and_eshop (corp_no, goods_code, eshop_type);

INSERT INTO diteng_mall.gms_goods_and_eshop (uid_, corp_no_, goods_code_, status_, eshop_type_, eshop_name_, eshop_goods_url_, app_user_, app_date_, update_user_, update_date_) VALUES (1, '911001', '911001000373', 1, 1, '天猫', 'https://detail.tmall.com/item.htm?spm=a220m.1000858.1000725.1.1f421697IuWhN1&id=572119490350&skuId=3881037826102&areaId=440300&user_id=1665801337&cat_id=2&is_b=1&rn=93ebd523fa9ad58d1ab39dfcb3b1d234', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_eshop (uid_, corp_no_, goods_code_, status_, eshop_type_, eshop_name_, eshop_goods_url_, app_user_, app_date_, update_user_, update_date_) VALUES (2, '911001', '911001000373', 1, 2, '京东', 'https://item.jd.com/46601339576.html', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_eshop (uid_, corp_no_, goods_code_, status_, eshop_type_, eshop_name_, eshop_goods_url_, app_user_, app_date_, update_user_, update_date_) VALUES (3, '911001', '001', 1, 0, '淘宝', 'https://item.taobao.com/item.htm?spm=a230r.1.14.29.5ae5b5b1MTnShu&id=600950095413&ns=1&abbucket=10#detail', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_eshop (uid_, corp_no_, goods_code_, status_, eshop_type_, eshop_name_, eshop_goods_url_, app_user_, app_date_, update_user_, update_date_) VALUES (4, '911001', '001', 1, 2, '京东', 'https://item.jd.com/10457186342.html', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_eshop (uid_, corp_no_, goods_code_, status_, eshop_type_, eshop_name_, eshop_goods_url_, app_user_, app_date_, update_user_, update_date_) VALUES (5, '911001', '001', 1, 1, '天猫', 'https://detail.tmall.com/item.htm?spm=a230r.1.14.6.5ae5b5b1MTnShu&id=618202918534&cm_id=140105335569ed55e27b&abbucket=10&sku_properties=132934279:603306063', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_eshop (uid_, corp_no_, goods_code_, status_, eshop_type_, eshop_name_, eshop_goods_url_, app_user_, app_date_, update_user_, update_date_) VALUES (6, '911001', '0212DYRDR40350', 1, 0, '淘宝', 'https://item.taobao.com/item.htm?spm=a230r.1.14.54.21b13989N3wfFb&id=571018181265&ns=1&abbucket=10#detail', '91100123', '2020-10-14 19:08:10', '91100123', '2020-10-14 19:08:24');