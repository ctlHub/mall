create table gms_goods_and_tag
(
    uid        int unsigned auto_increment comment '主键UID'
        primary key,
    corp_no    varchar(10) not null comment '账套代码',
    goods_code varchar(18) not null comment '商品料号',
    tag_code   varchar(30) not null comment '标签代码'
)
    comment '商品标签关联表';

create index idx_corpAndGoods
    on gms_goods_and_tag (corp_no, goods_code);

create index idx_corpAndTagCode
    on gms_goods_and_tag (corp_no, tag_code);

INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (21, '911001', '0910544', '756156875686879232', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (22, '911001', '0910544', '755161918319779840', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (23, '911001', '0910544', '756158496349167616', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (24, '911001', '0910544', '756169926390734848', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (25, '911001', '0910545', '756156875686879232', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (26, '911001', '0910545', '755161918319779840', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (27, '911001', '0910545', '756158496349167616', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (28, '911001', '0910545', '756169926390734848', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (29, '911001', '0910557', '756156875686879232', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (30, '911001', '0910557', '755161918319779840', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (31, '911001', '0910557', '756158496349167616', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (32, '911001', '0910557', '756169926390734848', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (33, '911001', '001', '756170542114562048', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (34, '911001', '001', '756170655331409920', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (35, '911001', '010001', '756170542114562048', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (36, '911001', '010001', '756170655331409920', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (37, '911001', '0212DYRDR40350', '756170542114562048', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (38, '911001', '0212DYRDR40350', '756170655331409920', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (39, '911001', '06JINLONG0040', '756170542114562048', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_goods_and_tag (uid_, corp_no_, goods_code_, tag_code_, app_user_, app_date_, update_user_, update_date_) VALUES (40, '911001', '06JINLONG0040', '756170655331409920', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');