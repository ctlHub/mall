create table gms_goods_description
(
    uid        int unsigned auto_increment comment '主键UID'
        primary key,
    corp_no    varchar(10)            not null comment '账套代码',
    goods_code varchar(18)            not null comment '商品料号',
    status_    int(3)                 not null comment '启用状态',
    title      varchar(30) default '' not null comment '说明标题',
    content    text                   null comment '内容'
)
    comment '商品说明表';

create index idx_goods
    on gms_goods_description (corp_no, goods_code);

INSERT INTO diteng_mall.gms_goods_description (uid_, corp_no_, goods_code_, code_, status_, title_, content_, app_user_, app_date_, update_user_, update_date_) VALUES (1, '911001', '911001000373', '', 1, '商品详情图1', 'http://img12.360buyimg.com/imgzone/jfs/t1/39865/14/4110/678302/5cc7c895E614029ae/544b9e639e916025.jpg', '19400123', '2020-10-14 15:43:22', '19400123', '2020-10-14 15:43:22');
INSERT INTO diteng_mall.gms_goods_description (uid_, corp_no_, goods_code_, code_, status_, title_, content_, app_user_, app_date_, update_user_, update_date_) VALUES (2, '911001', '911001000373', '', 1, '商品详情图1', 'http://img30.360buyimg.com/imgzone/jfs/t1/39150/8/4102/643529/5cc7c897E61468513/1868a6b7c89ac2a0.jpg', '19400123', '2020-10-14 15:43:22', '19400123', '2020-10-14 15:43:22');
INSERT INTO diteng_mall.gms_goods_description (uid_, corp_no_, goods_code_, code_, status_, title_, content_, app_user_, app_date_, update_user_, update_date_) VALUES (7, '911001', '001', '760179060965449728', 1, null, 'https://vinetest.oss-cn-hangzhou.aliyuncs.com/911001/productDescription/001/{a9d4d34b-8d48-49d8-ba96-fba058f31879}.jpg', '19400123', '2020-10-14 15:43:22', '19400123', '2020-10-14 15:43:22');
INSERT INTO diteng_mall.gms_goods_description (uid_, corp_no_, goods_code_, code_, status_, title_, content_, app_user_, app_date_, update_user_, update_date_) VALUES (10, '911001', '001', '766014710314770432', 1, null, 'https://vinetest.oss-cn-hangzhou.aliyuncs.com/911001/productDescription/001/{ce854da1-4383-4e50-a9e5-50120d622f87}.jpg', '91100123', '2020-10-14 19:08:59', '91100123', '2020-10-14 19:08:59');
INSERT INTO diteng_mall.gms_goods_description (uid_, corp_no_, goods_code_, code_, status_, title_, content_, app_user_, app_date_, update_user_, update_date_) VALUES (11, '911001', '911001000373', '766222950093971456', 1, null, 'https://vinetest.oss-cn-hangzhou.aliyuncs.com/911001/productDescription/001/{ce854da1-4383-4e50-a9e5-50120d622f87}.jpg', '91100123', '2020-10-15 08:56:51', '91100123', '2020-10-15 08:56:51');