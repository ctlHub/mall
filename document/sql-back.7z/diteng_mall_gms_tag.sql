create table gms_tag
(
    uid     int unsigned auto_increment comment '主键UID'
        primary key,
    corp_no varchar(10)             not null comment '企业编号',
    code    varchar(30)             not null comment '标签代码（雪花Long）',
    name    varchar(20)             not null comment '标签名称',
    type    varchar(20)  default '' null comment '标签类型(选大类)',
    remark  varchar(100) default '' null comment '备注',
    constraint uk
        unique (corp_no, code)
)
    comment '商品标签表';

INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (3, '911001', '3', '双十二', '假饵类', '', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (4, '911001', '4', '618', '假饵类', '', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (15, '911001', '755161918319779840', '打折', '', '', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (16, '911001', '755337787185192960', '修改打折', '51', 'remark', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (18, '911001', '756156875686879232', '配件标签2', '配件类', '222', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (19, '911001', '756158222545002496', '配件标签1', '配件类', '22233333', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (20, '911001', '756158407308288000', '标签12', '钓箱类', '22233333', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (21, '911001', '756158431207432192', '标签1', '钓箱类', '22233333', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (22, '911001', '756158496349167616', '标签123', '', '22233333', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (23, '911001', '756167240383619072', '桌子', '', '', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (24, '911001', '756169926390734848', '儿童桌子', '', '', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (25, '911001', '756170542114562048', '粉色儿童桌子', '', '', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (26, '911001', '756170655331409920', '蓝色色儿童桌子', '', '', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (27, '911001', '756170913541152768', '蓝色色4儿童桌子', '', '', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (28, '911001', '756171181674618880', '蓝色色49儿童桌子', '', '', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (29, '911001', '756171351065780224', '蓝色色492儿童桌子', '', '', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (30, '911001', '756171601155350528', '蓝色色4942儿童桌子', '', '', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');
INSERT INTO diteng_mall.gms_tag (uid_, corp_no_, code_, name_, type_, remark_, app_user_, app_date_, update_user_, update_date_) VALUES (40, '911001', '766033945770401792', '十月十四号促销', '假饵类', '十月十四号促销修改备注', '91100123', '2020-10-14 20:25:25', '91100123', '2020-10-15 08:19:14');