create table mms_merchant
(
    uid        int unsigned auto_increment comment '主键UID'
        primary key,
    corp_no    varchar(10)  not null comment '帐套代码',
    name       varchar(80)  not null comment '商家名称',
    status_    int          not null comment '状态',
    logo       varchar(255) null comment '页面上的logo',
    phone_icon varchar(255) null comment '手机版选择商家图标',
    pc_icon    varchar(255) null comment '电脑版选择商家图标',
    constraint uk
        unique (corp_no)
)
    comment '商家表';

INSERT INTO diteng_mall.mms_merchant (uid_, corp_no_, name_, status_, industry_code_, logo_, phone_icon_, pc_icon_, app_user_, app_date_, update_user_, update_date_) VALUES (1, '911001', '深圳华软', 1, '766358539401322496', 'https://fgsc.site/forms/images/shoppingImages/logo.png', 'https://fgsc.site/forms/images/ditenglogo.png', 'https://fgsc.site/forms/images/ditenglogo.png', '19400123', '2020-10-14 00:00:00', '19400123', '2020-10-14 00:00:00');